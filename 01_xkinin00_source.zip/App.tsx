// File: App.tsx
// Author: Kininbayev Timur (xkinin00)
// This is the main entry point of the application, setting up global navigation.
// It defines navigation stacks for authenticated and unauthenticated users.
// Uses AuthContext and EventContext to manage global authentication state and events data.
// Depending on whether the user is authenticated, it navigates to different stacks of screens.

import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Image, View, Modal } from 'react-native';
import HomeScreen from './screens/HomeScreen';
import EventDetails from './screens/EventDetails';
import LoginScreen from './screens/LoginScreen';
import RegistrationScreen from './screens/RegistrationScreen';
import MapScreen from './screens/MapScreen';
import LeaderBoardScreen from './screens/LeaderBoardScreen';
import CreateEvent from './screens/CreateEvent';
import { EventProvider } from './context/EventContext';
import { AuthProvider, AuthContext } from './context/AuthContext';
import StartScreen from './screens/StartScreen';
import ProfileScreen from './screens/ProfileScreen';
import CategoryDetailsScreen from './screens/CategoryDetailsScreen';
import HomeScreenIcon from './images/icons/HomeScreenIcon.png';
import LeaderBoardIcon from './images/icons/LeaderBoardIcon.png';
import MapIcon from './images/icons/MapIcon.png';
import ProfileIcon from './images/icons/ProfileIcon.png';
import CreateEventIcon from './images/icons/CreateEventIcon.png';
import QRScannerScreen from './screens/QRScannerScreen';
import ChatListScreen from './screens/ChatListScreen';
import ChatScreen from './screens/ChatScreen';
import MainTabs from './components/MainTabs';
import { setCustomText } from 'react-native-global-props';

// Create two separate stacks:
// 1. StartScreenStack for non-authenticated users (login/signup/start screens)
// 2. RootStack for authenticated users (main app screens)
const StartScreenStack = createStackNavigator();
const RootStack = createStackNavigator();

// Global text style configuration using react-native-global-props
const customTextProps = {
  style: {
    fontFamily: 'Gilroy-Regular',
  },
};

setCustomText(customTextProps);

// Root stack for authenticated users - contains the main navigation of the app
const RootStackScreen: React.FC = () => (
  <RootStack.Navigator>
    {/* MainTabs is the bottom tab navigator with the core sections of the app */}
    <RootStack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
    {/* Additional screens that can be navigated to from within the app */}
    <RootStack.Screen name="MapScreen" component={MapScreen} options={{ headerShown: false }} />
    <RootStack.Screen name="EventDetails" component={EventDetails} options={{ headerShown: false }} />
    <RootStack.Screen name="CategoryDetails" component={CategoryDetailsScreen} options={{ headerShown: false }} />
    <RootStack.Screen name="QRScanner" component={QRScannerScreen} options={{ headerShown: false }} />
    <RootStack.Screen name="CreateEvent" component={CreateEvent} options={{ headerShown: false }} />
    <RootStack.Screen name="ChatScreen" component={ChatScreen} options={{ headerShown: false }} />
    <RootStack.Screen name="ChatListScreen" component={ChatListScreen} options={{ headerShown: false }} />
  </RootStack.Navigator>
);

// Stack for unauthenticated users - shows start screen, login, and signup
const StartScreenStackScreen: React.FC = () => (
  <StartScreenStack.Navigator>
    <StartScreenStack.Screen name="StartScreen" component={StartScreen} options={{ headerShown: false }} />
    <StartScreenStack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
    <StartScreenStack.Screen name="SignUp" component={RegistrationScreen} options={{ headerShown: false }} />
  </StartScreenStack.Navigator>
);

// The main App component:
// Uses AuthProvider and EventProvider for global state.
// Depending on authentication state, it either shows the authenticated stack or the start stack.
const App: React.FC = () => (
  <AuthProvider>
    <EventProvider>
      <NavigationContainer>
        <AuthContext.Consumer>
          {({ isSignedIn }) => (
            isSignedIn ? <RootStackScreen /> : <StartScreenStackScreen />
          )}
        </AuthContext.Consumer>
      </NavigationContainer>
    </EventProvider>
  </AuthProvider>
);

export default App;
